/* Program that calculates a ticket discount.
 * 
 * Date: Oct. 12, 2016
 * Author: V. Doufexi
 */

#include<stdio.h>

int main (int argc, char *argv[]) {

	const double LOW_RATE = 0.15;  /* discount rates */
	const double HIGH_RATE = 0.35;
	const int LIMIT = 10; /* to determine discount rate */
	double base_price, discount, full_price, final_price;
	int num_tickets;

	printf("Ticket price: ");
	scanf("%lf", &base_price);
	printf("How many: ");
	scanf("%d", &num_tickets);

	full_price = base_price * num_tickets;
	/* fewer than LIMIT tickets ==> low discount rate, 
       more ==> high discount rate */
	discount = (num_tickets < LIMIT) ? 
				full_price * LOW_RATE : 
				full_price * HIGH_RATE;
	final_price = full_price - discount;

	printf("\nTickets: %d @ %.2lf\n", num_tickets, base_price);
	printf("Discount: %.2lf\n", discount);
	printf("Final price: %.2lf\n", final_price);

	return 0;
}
