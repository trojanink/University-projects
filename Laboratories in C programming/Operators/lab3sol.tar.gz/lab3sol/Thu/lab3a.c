/* Program that calculates the area and surface of a right circular cone.
 * 
 * Date : Oct. 12, 2016
 * Author: V. Doufexi
 */

#include<stdio.h>
#include<math.h>

int main (int argc, char *argv[]) {

	double radius, height, area, volume;
	const double PI = 3.14159;
	
	printf("Radius: ");
	scanf("%lf", &radius);
	printf("Height: ");
	scanf("%lf", &height);
	
	area = PI * radius * (radius + sqrt(radius * radius + height * height));
	volume = PI * radius * radius * height / 3.0;

	printf("\nArea: %.3lf, Volume: %.3lf\n", area, volume);

	return 0;
}
