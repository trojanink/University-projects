/* Program that solves a quadratic equation.
 * 
 * Assumptions: 
 *  - The quadratic coefficient is non-zero
 *  - The determinant is positive.
 * 
 * Date : Oct. 12, 2016
 * Author: V. Doufexi
 */

#include<stdio.h>
#include<math.h>

int main (int argc, char *argv[]) {

	double quadratic, linear, constant;  /* coefficients */
	double determinant, root1, root2;
	
 	printf("Coefficients:\n");
	printf("Quadratic: ");
	scanf("%lf", &quadratic);
	printf("Linear: ");
	scanf("%lf", &linear);
	printf("Constant: ");
	scanf("%lf", &constant);

	determinant = linear * linear - 4 * quadratic * constant;
	root1 = (-linear + sqrt(determinant)) / (2 * quadratic);
	root2 = (-linear - sqrt(determinant)) / (2 * quadratic);

	printf("\nroot1 = %.4lf, root2 = %.4lf\n", root1, root2);
	return 0;
}
