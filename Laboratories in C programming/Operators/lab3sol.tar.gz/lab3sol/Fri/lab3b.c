/* Program that calculates a product discount or surcharge based on a given
 * integer value.
 * 
 * Date: Oct. 12, 2016
 * Author: V. Doufexi
 */

#include<stdio.h>

int main (int argc, char *argv[]) {

	const double DISCOUNT_RATE = 0.10;
	const double SURCHARGE_RATE = 0.25;
	double base_price, variation, final_price;
	int which_action;

	printf("Base price: ");
	scanf("%lf", &base_price);
	printf("+/-: ");
	scanf("%d", &which_action);

	/* even which_action ==> surcharge
	   odd which_action ==> discount
     */
	variation = (which_action % 2) ? 
				- base_price * DISCOUNT_RATE : 
				base_price * SURCHARGE_RATE;
	final_price = base_price + variation;

	printf("\nBase price: %.2lf\n", base_price);
	printf("Mod amount: %.2lf\n", variation);
	printf("Final price: %.2lf\n", final_price);

	return 0;
}
