#include<stdio.h>

int main (int argc, char *argv[]) {
	
	printf("Consumption (KWh): ");

	printf("Last bill on time? (y/n) ");

	printf("Second to last bill on time? (y/n) ");

	return 0;
}
