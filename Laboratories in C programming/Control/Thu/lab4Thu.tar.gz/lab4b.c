#include<stdio.h>

int main (int argc, char *argv[]) {
	
	printf("\tC. Coke\n");
	printf("\tD. Diet Coke\n");
	printf("\tS. Sprite\n");
	printf("\tW. Water\n");
	printf("\t==>");

	return 0;
}
	
