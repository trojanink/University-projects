#include<stdio.h>

int main (int argc, char *argv[]) {
	
	printf("Enter expression: ");
	
	return 0;
}
