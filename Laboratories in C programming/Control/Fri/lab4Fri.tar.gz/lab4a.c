#include<stdio.h>

int main (int argc, char *argv[]) {

	printf("Income (Euro): ");
	printf("Any kids? (y/n): ");
	printf("Paid tax for last year? (y/n): ");
	
	return 0;
}
